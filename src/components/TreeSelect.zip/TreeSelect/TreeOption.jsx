import React, { useRef, useEffect } from 'react'

const TreeOption = ({ item, selected, onSelect, multiple, treeIcon, renderIcon, treeCheckable }) => {
    const checkboxRef = useRef();
    // const isChecked = multiple
    //     ? selected.includes(item.value)
    //     : selected === item.value;
    // console.log("selected:", selected, "item.value:", item.value, "isChecked:", isChecked);

    // Ensure selected is an array to prevent errors
    const safeSelected = Array.isArray(selected) ? selected : [];

    // Helper: get all descendant values recursively
    const getAllDescendantValues = (node) => {
        if (!node.children || node.children.length === 0) return [node.value];
        return node.children.flatMap(getAllDescendantValues);
    };

    // Get all descendants of this node
    const allDescendants = getAllDescendantValues(item);

    // Determine if all descendants are selected
    const allSelected = allDescendants.every(val => safeSelected.includes(val));
    // Determine if some descendants are selected
    const someSelected = allDescendants.some(val => safeSelected.includes(val));

    // For non-multiple (single selection) mode fallback
    const isChecked = multiple
    ? (safeSelected.includes(item.value) || allSelected)
    : selected === item.value;



    // Update indeterminate state on the checkbox input
    useEffect(() => {
        if (checkboxRef.current) {
            checkboxRef.current.indeterminate = multiple && someSelected && !allSelected;
        }
    }, [someSelected, allSelected, multiple]);

    const handleClick = () => {
        onSelect(item);
        console.log(item)
    };

    return (
        <li className={`tree-option ${isChecked ? 'selected' : ''}`}>
            <div className="tree-option-label dropdown-icons d-flex align-items-center" onClick={handleClick}>
                {treeIcon && item.iconType && (
                    <span className="me-2">{renderIcon(item.iconType)}</span>
                )}
                {treeCheckable && <input ref={checkboxRef} type="checkbox" readOnly checked={isChecked} />}
                {item.title}
            </div>
            {item.children && item.children.length > 0 && (
                <ul className="tree-submenu">
                    {item.children.map((child) => (
                        <TreeOption
                            key={child.value}
                            item={child}
                            selected={selected}
                            onSelect={onSelect}
                            multiple={multiple}
                            treeIcon={treeIcon}
                            renderIcon={renderIcon}
                            treeCheckable={treeCheckable}
                        />
                    ))}
                </ul>
            )}
        </li>
    );
};

export default TreeOption;
